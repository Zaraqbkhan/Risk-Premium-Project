# Clean workspace 
rm(list = ls())

# Set the stop limit
L <- 10118100

# Set seed (so you get reproducible results)
set.seed(123)
df <- read.csv(
  "C:/Users/47462/OneDrive/Desktop/Risk Premium Project/Dataset/rank_annual.csv",
  stringsAsFactors = FALSE,
  fileEncoding = "latin1"
)

class(df)
str(df)
head(df)


df$Rank_Ult_Total <- as.numeric(gsub("[^0-9.]", "", df$Rank_Ult_Total))

S <- df$Rank_Ult_Total
length(S)      # number of historical years (should be ~8 or 9)
summary(S)



M <- 200000  # number of simulated years (increase if you want)
S_sim <- sample(S, size = M, replace = TRUE)


p_hat <- mean(S_sim > L)
p_hat


B <- 5000
p_boot <- numeric(B)

for (b in 1:B) {
  S_b <- sample(S, size = length(S), replace = TRUE)     # resample the historical years
  S_sim_b <- sample(S_b, size = 50000, replace = TRUE)   # simulate within that resample
  p_boot[b] <- mean(S_sim_b > L)
}

quantile(p_boot, c(0.025, 0.5, 0.975))


mean_S <- mean(S)
q95 <- quantile(S_sim, 0.95)
q99 <- quantile(S_sim, 0.99)
max_S <- max(S)

list(
  mean_annual_rank = mean_S,
  max_historical = max_S,
  VaR_95 = q95,
  VaR_99 = q99,
  prob_exceed = p_hat
)

hist(S_sim, breaks = 60,
     main = "Simulated Annual Ranking Totals",
     xlab = "Annual RankTotal")
abline(v = L, lwd = 2)





writeLines(capture.output(results_list), "outputs/r_results.txt")
png("outputs/histogram_rank_total.png", width=900, height=600)
hist(S_sim, breaks=60, main="Simulated Annual Ranking Totals", xlab="Annual RankTotal")
abline(v=L, lwd=2)
dev.off()
